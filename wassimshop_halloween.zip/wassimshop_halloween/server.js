const express = require("express");
const session = require("express-session");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || "Wassimshop";
const ADMIN_PASS = process.env.ADMIN_PASS || "Wassimshop";
const DATA_FILE = path.join(__dirname, "data.json");

app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-secret-before-deploying",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

function loadData() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return { winner: null, logs: [] }; }
}
function saveData(data) { fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2)); }

app.get("/api/status", (req, res) => {
  const d = loadData();
  res.json({ claimed: !!d.winner, winner: d.winner ? d.winner.name : null });
});
app.post("/api/attempt", (req, res) => {
  const name = String(req.body.name || "").trim().slice(0, 32);
  const result = String(req.body.result || "abandon").slice(0, 20);
  const errors = Math.max(0, Math.min(10, Number(req.body.errors) || 0));
  if (!name) return res.status(400).json({ error: "Entre un pseudo." });
  const d = loadData();
  const log = { name, result, errors, date: new Date().toISOString() };
  if (result === "reussi") {
    if (d.winner) {
      d.logs.push({ ...log, result: "recompense_deja_pr prise" });
      saveData(d);
      return res.json({ ok: true, claimed: true, winner: d.winner.name });
    }
    d.winner = { name, date: log.date };
    d.logs.push(log);
    saveData(d);
    return res.json({ ok: true, claimed: true, winner: name, won: true });
  }
  d.logs.push(log);
  saveData(d);
  res.json({ ok: true, claimed: !!d.winner, winner: d.winner ? d.winner.name : null });
});
app.post("/api/admin/login", (req, res) => {
  if (String(req.body.username || "") === ADMIN_USER && String(req.body.password || "") === ADMIN_PASS) {
    req.session.admin = true;
    return res.json({ ok: true });
  }
  res.status(401).json({ error: "Identifiants incorrects." });
});
app.post("/api/admin/logout", (req, res) => { req.session.destroy(() => res.json({ ok: true })); });
app.get("/api/admin/logs", (req, res) => {
  if (!req.session.admin) return res.status(401).json({ error: "Connexion requise." });
  const d = loadData();
  res.json({ winner: d.winner, logs: d.logs.slice().reverse() });
});
app.post("/api/admin/reset", (req, res) => {
  if (!req.session.admin) return res.status(401).json({ error: "Connexion requise." });
  saveData({ winner: null, logs: [] });
  res.json({ ok: true });
});
app.listen(PORT, () => console.log(`Wassim Shop Halloween lancé sur le port ${PORT}`));
