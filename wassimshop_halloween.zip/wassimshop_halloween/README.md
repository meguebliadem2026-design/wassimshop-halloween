# Wassim Shop — Halloween Quiz

## Lancer en local
1. Installe Node.js sur un ordinateur ou un environnement compatible.
2. Dans ce dossier, lance `npm install`
3. Lance `npm start`
4. Ouvre `http://localhost:3000`

## Identifiants administrateur par défaut
- Utilisateur : `Wassimshop`
- Mot de passe : `Wassimshop`

## Avant de publier
Dans les variables d'environnement de l'hébergeur, configure :
- `ADMIN_USER` : ton identifiant admin
- `ADMIN_PASS` : un mot de passe fort et unique (ne garde pas le mot de passe par défaut)
- `SESSION_SECRET` : une longue chaîne secrète aléatoire
- `NODE_ENV=production`

**Important :** le fichier `data.json` stocke le gagnant et les logs. Il faut un hébergeur qui conserve les fichiers entre les redémarrages, sinon utilise une base de données persistante. Le gagnant unique fonctionne entre visiteurs via le serveur, pas avec une page HTML ouverte seule.
Le deuxième échec arrête la partie. La question libre du film d'horreur vérifie seulement qu'une réponse a été saisie (au moins 2 caractères), pas que le titre existe réellement.
